ICE RUSH — версия для ПК (Windows), Electron

Сборка в облаке GitHub (ПК не нужен):
 1. Загрузи в репозиторий IceRush_PC_project.zip (и музыку Music/music_part1-3.zip, если ещё не загружена).
 2. Создай файл .github/workflows/pc.yml (текст в pc.yml).
 3. Actions > Build PC > Run workflow. Через ~5-8 минут скачай IceRush-Windows из Artifacts.
 4. Внутри zip лежит IceRush-версия-portable.exe — запускай двойным щелчком, установка не нужна.

Управление: Пробел/клик — прыжок, A D / стрелки — ходьба, J — огонь, Shift — рывок, Esc — пауза/назад, F11 — полный экран.
Сохранения лежат в профиле приложения (папка пользователя). Музыка берётся из app/music (добавляется при сборке).
Запуск из исходников (есть Node.js): npm install && npm start
