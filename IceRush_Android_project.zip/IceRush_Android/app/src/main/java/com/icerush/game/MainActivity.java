package com.icerush.game;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
  WebView w;
  ClipboardManager cm;

  class Bridge {
    @JavascriptInterface public void copy(final String t) {
      runOnUiThread(() -> cm.setPrimaryClip(ClipData.newPlainText("level", t)));
    }
    @JavascriptInterface public String paste() {
      try {
        if (cm.hasPrimaryClip() && cm.getPrimaryClip().getItemCount() > 0) {
          CharSequence c = cm.getPrimaryClip().getItemAt(0).coerceToText(MainActivity.this);
          return c == null ? "" : c.toString();
        }
      } catch (Exception e) { }
      return "";
    }
    @JavascriptInterface public void share(final String t) {
      runOnUiThread(() -> {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TEXT, t);
        startActivity(Intent.createChooser(i, "Поделиться уровнем"));
      });
    }
  }

  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
    w = new WebView(this);
    WebSettings s = w.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setMediaPlaybackRequiresUserGesture(false);
    w.setBackgroundColor(0xff06142a);
    w.setWebViewClient(new WebViewClient());
    w.addJavascriptInterface(new Bridge(), "AndroidBridge");
    setContentView(w);
    w.loadUrl("file:///android_asset/index.html");
    hide();
  }

  void hide() {
    getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
      | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
      | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
  }
  @Override public void onWindowFocusChanged(boolean f) { super.onWindowFocusChanged(f); if (f) hide(); }
  @Override protected void onPause() { super.onPause(); w.onPause(); }
  @Override protected void onResume() { super.onResume(); w.onResume(); }
  @Override public void onBackPressed() {
    w.evaluateJavascript("state", v -> {
      if (v != null && v.contains("menu")) finish();
      else w.evaluateJavascript("dispatchEvent(new KeyboardEvent('keydown',{code:'Escape'}))", null);
    });
  }
}
