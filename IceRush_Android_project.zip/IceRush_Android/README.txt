ICE RUSH 0.3.0 — как собрать APK (~55 МБ с музыкой)

Файлы: IceRush_Android_project.zip + music_part1.zip, music_part2.zip, music_part3.zip
(музыка разбита на 3 архива, потому что GitHub в браузере принимает файлы до 25 МБ).

GitHub:
 1. Загрузи ВСЕ 4 zip в репозиторий (Add file > Upload files > Commit changes).
 2. В .github/workflows/build.yml должен быть шаг распаковки всех архивов:
      - run: for z in IceRush_Android_project.zip music_part*.zip; do unzip -o "$z"; done
 3. Actions > Build APK > Run workflow. Скачай IceRush-apk из Artifacts.

Android Studio: распакуй все 4 архива в одну папку (с заменой) и открой IceRush_Android.

Ключ app/icerush.jks лежит в открытом виде — держи репозиторий Private.
Если музыки в APK нет, игра сама переключится на встроенную синтезированную.

ОБЩЕЕ ОНЛАЙН-СООБЩЕСТВО БЕЗ КОДОВ (0.2.9)
 1. На jsonblob.com вставь {"levels":[]} и нажми Save; ID = число/код из адреса страницы.
 2. В корень репозитория добавь файл community.txt с одним этим ID.
 3. Собери APK — workflow подставит ID в игру, и все игроки сразу попадают в общий каталог.

FIREBASE (0.3.2): в корень репозитория добавь firebase.txt из двух строк:
  1-я строка — apiKey, 2-я — projectId. Workflow подставит их в игру.
Если firebase.txt нет, игра использует community.txt (jsonblob) или локальный режим.

CLOUDFLARE (0.3.3): в корень репозитория добавь cloudflare.txt с адресом воркера в одной строке
(https://имя.аккаунт.workers.dev). Workflow подставит его в игру. Код воркера — icerush-worker.js.
Приоритет: Cloudflare > Firebase > jsonblob > локально.

СВОЙ ХОСТИНГ (0.3.4): загрузи api.php на хостинг с PHP+MySQL (впиши в него данные базы и админ-пароль),
в репозиторий добавь server.txt с адресом https://твой-сайт/api.php — workflow подставит его в игру.

SUPABASE (0.3.5): в корень репозитория добавь supabase.txt из двух строк: 1) Project URL (https://xxxx.supabase.co), 2) publishable/anon key.
SQL-скрипт — supabase.sql (SQL Editor). Приоритет: Supabase > свой сервер/Cloudflare > Firebase > jsonblob > локально.

0.3.2: онлайн-сообщество временно закрыто (в игре const COMM_ON=false). Свой фон и музыка в редакторе: нужен выбор файла (в APK добавлен).
В Настройках → Игра можно вернуть старый интерфейс (0.3.1).
