ICE RUSH 0.2.7 — как собрать APK

Это подписанная release-сборка (ключ app/icerush.jks уже в проекте).
Подпись постоянная, поэтому новые версии ставятся поверх старой.

GitHub (на телефоне или компьютере)
 1. Загрузи IceRush_Android_project.zip в репозиторий (Add file > Upload files).
 2. В файле .github/workflows/build.yml замени «gradle assembleDebug» на
    «gradle assembleRelease», а путь артефакта на
    IceRush_Android/app/build/outputs/apk/release/app-release.apk
 3. Actions > Build APK > Run workflow. Скачай IceRush-apk из Artifacts.

Android Studio
 Build > Generate Signed Bundle / APK > APK. Либо терминал: gradle assembleRelease.

ВАЖНО: ключ лежит в открытом виде внутри проекта — держи репозиторий Private.
Предупреждение Play Protect при установке вне Google Play остаётся нормой.
