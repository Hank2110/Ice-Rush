ICE RUSH 0.2.5 — как собрать APK

ВАРИАНТ A — на компьютере, Android Studio
 1. Скачай и установи Android Studio (developer.android.com/studio).
 2. Распакуй этот архив.
 3. Android Studio: File > Open > выбери папку IceRush_Android.
 4. Подожди, пока внизу закончится «Gradle sync» (первый раз 5-10 минут, нужен интернет).
 5. Меню Build > Build Bundle(s) / APK(s) > Build APK(s).
 6. Внизу справа нажми «locate» — файл app-debug.apk
    (app/build/outputs/apk/debug/app-debug.apk).

ВАРИАНТ B — без установки программ (GitHub, бесплатно)
 1. Зарегистрируйся на github.com, нажми New repository (например icerush).
 2. Загрузи ВСЁ содержимое папки IceRush_Android, включая скрытую папку .github
    (проще всего: установи GitHub Desktop и перетащи папку; веб-загрузка
    иногда пропускает папки, начинающиеся с точки).
 3. Вкладка Actions > Build APK > Run workflow.
 4. Через ~5 минут открой запуск, внизу «Artifacts» > IceRush-apk — скачай.

УСТАНОВКА НА ТЕЛЕФОН
 1. Перекинь app-debug.apk на телефон (USB, облако, Telegram).
 2. Открой файл. Если телефон попросит — разреши «установку из неизвестных
    источников» для этого приложения.
 3. Запусти Ice Rush. Игра работает офлайн.

Игра лежит в app/src/main/assets/index.html. Если обновишь её — пересобери APK.
Кнопка «Назад»: в меню выходит из игры, в остальных местах работает как Esc.
Сборка debug — для личной установки. Для Google Play нужна подписанная release-сборка.
